<script setup>
let x = 3
</script>

<template>
    <div>
        <h1>About</h1>
        <div>
            帮助记录简历投递状态
        </div>
    </div>
</template>

<style scoped></style>
